import React, { useState } from 'react';
import Swal from 'sweetalert2';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import type { User } from '@/lib/types/user';

interface BlockProps {
  user: User;
  token: string;
}

export const Block: React.FC<BlockProps> = ({ user, token }) => {
  const navigate = useNavigate();
  
  const logout = (): void => {
    localStorage.removeItem("authResponse");
    navigate("/");
  }

  const [color, setColor] = useState<string>(user.blocked ? '#70ceab' : '#d33');
  const [block, setBlock] = useState<boolean>(!!user.blocked);

  const confirmBlock = (): void => {
    Swal.fire({
      title: "¿Estás Seguro?",
      text: `¿Deseas ${block ? 'desbloquear' : 'bloquear'} un usuario?`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: `${block ? 'Desbloquear' : 'Bloquear'}`
    }).then((result) => {
      if (result.isConfirmed) {
        // Alternar el estado de bloqueo
        const newBlockStatus = !block;
        setBlock(newBlockStatus);
        blockUser(newBlockStatus);
      }
    });
  }

  const blockUser = async (newBlockStatus: boolean): Promise<void> => {
    const headers = {
      'cnrsms_token': token,
    };

    try {
      // Simulación de la solicitud sin backend
      console.log(`Simulando ${newBlockStatus ? 'bloquear' : 'desbloquear'} usuario ${user.id}`);
      
      // Para pruebas con datos simulados
      await new Promise(resolve => setTimeout(resolve, 500)); // Simular delay de red
      
      // Mostrar el mensaje de éxito
      Swal.fire({
        title: 'Operación Exitosa',
        text: `Se ha ${newBlockStatus ? 'bloqueado' : 'desbloqueado'} el usuario ${user.name || user.email || user.id}`,
        icon: 'success',
        showCancelButton: false,
        confirmButtonColor: "#25293d",
        confirmButtonText: 'Ok'
      }).then((result) => {
        if (result.isConfirmed) {
          // Solo recargar si estás en producción con backend
          // location.reload();
          
          // Para desarrollo sin backend, actualizamos el estado visual
          setBlock(newBlockStatus);
          setColor(newBlockStatus ? '#70ceab' : '#d33');
        }
      });

      // Código real con axios (comentado para desarrollo sin backend)
      /*
      const response = await axios.put(`users/edit/${user.id}`,
        {
          blocked: newBlockStatus
        },
        { headers }
      );
      
      console.log('Respuesta del servidor:', response.data);
      
      if (result.isConfirmed) {
        location.reload();
      }
      */
    }
    catch (error) {
      // Manejo de errores con axios
      if (axios.isAxiosError(error)) {
        if (error.response?.data?.message === 'Token expirado') {
          Swal.fire({
            title: 'Inicio de sesion expirado',
            text: 'Vuelve a ingresar a la plataforma',
            icon: 'error',
            confirmButtonText: 'Ok'
          });
          logout();
          return;
        }
        
        console.error('Error en la solicitud:', error.response?.data || error.message);
      } else {
        console.error('Error inesperado:', error);
      }
      
      Swal.fire({
        title: 'Error',
        text: 'Estamos teniendo fallas técnicas. Usando modo simulación.',
        icon: 'error',
        confirmButtonText: 'Ok'
      }).then(() => {
        // En caso de error, usamos modo simulación
        setBlock(newBlockStatus);
        setColor(newBlockStatus ? '#70ceab' : '#d33');
      });
    }
  }

  return (
    <>
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" style={{cursor: "pointer"}} onClick={confirmBlock}>
            <g clipPath="url(#clip0_148_3538)">
            <path fillRule="evenodd" clipRule="evenodd" d="M20.4149 24H3.58538C3.13547 24 2.75586 23.6344 2.75586 23.1845V11.7118C2.75586 11.2619 3.13547 10.8963 3.58538 10.8963H4.99136V6.6362C4.99136 2.98067 7.97203 0 11.6276 0H12.3587C16.0283 0 18.9949 2.98067 18.9949 6.6362V10.8963H20.4149C20.8648 10.8963 21.2304 11.2619 21.2304 11.7118V23.1845C21.2304 23.6344 20.8648 24 20.4149 24ZM5.65217 10.8963H6.72071V6.6362C6.72071 3.92267 8.92809 1.71529 11.6276 1.71529H12.3587C15.0722 1.71529 17.2796 3.92267 17.2796 6.6362V10.8963H18.3481V6.6362C18.3481 3.33216 15.6627 0.660808 12.3587 0.660808H11.6276C8.33758 0.660808 5.65217 3.33216 5.65217 6.6362V10.8963ZM7.36746 10.8963H16.6188V6.6362C16.6188 4.28823 14.7067 2.3761 12.3587 2.3761H11.6276C9.27959 2.3761 7.36746 4.28823 7.36746 6.6362V10.8963ZM14.4958 21.0896H9.49048C9.25147 21.0896 9.09681 20.8506 9.19523 20.6257L10.5168 17.6872C8.99839 16.3374 9.95445 13.7926 11.9931 13.7926C14.0458 13.7926 15.0019 16.3374 13.4835 17.6872C13.6522 18.0527 14.8332 20.5975 14.8332 20.7663C14.8332 20.949 14.6785 21.0896 14.4958 21.0896ZM9.99663 20.4288H13.9896L12.7805 17.7293C12.7242 17.5888 12.7664 17.42 12.8929 17.3216C14.1583 16.4499 13.5397 14.4534 11.9931 14.4534C10.4606 14.4534 9.84198 16.4499 11.1074 17.3216C11.2339 17.42 11.2761 17.5888 11.2198 17.7293L9.99663 20.4288ZM3.58538 11.5571C3.48697 11.5571 3.41667 11.6274 3.41667 11.7118V23.1845C3.41667 23.2689 3.48697 23.3392 3.58538 23.3392H20.4149C20.4993 23.3392 20.5836 23.2689 20.5836 23.1845V11.7118C20.5836 11.6274 20.4993 11.5571 20.4149 11.5571H3.58538Z" fill="#222222"/>
            <path fillRule="evenodd" clipRule="evenodd" d="M17.2798 6.63628V10.8964H18.3483V6.63628C18.3483 3.33224 15.6629 0.660889 12.3588 0.660889H11.6277C8.33776 0.660889 5.65234 3.33224 5.65234 6.63628V10.8964H6.72089V6.63628C6.72089 3.92275 8.92827 1.71537 11.6277 1.71537H12.3588C15.0724 1.71537 17.2798 3.92275 17.2798 6.63628Z" fill="#999999"/>
            <path fillRule="evenodd" clipRule="evenodd" d="M20.4147 11.5571H3.58522C3.4868 11.5571 3.4165 11.6274 3.4165 11.7118V23.1845C3.4165 23.2689 3.4868 23.3392 3.58522 23.3392H20.4147C20.4991 23.3392 20.5835 23.2689 20.5835 23.1845V11.7118C20.5835 11.6274 20.4991 11.5571 20.4147 11.5571ZM13.4833 17.6872C13.652 18.0527 14.833 20.5976 14.833 20.7663C14.833 20.949 14.6784 21.0896 14.4956 21.0896H9.49032C9.2513 21.0896 9.09664 20.8506 9.19506 20.6257L10.5167 17.6872C8.99823 16.3374 9.95429 13.7926 11.993 13.7926C14.0457 13.7926 15.0017 16.3374 13.4833 17.6872Z" fill={color}/>
            <path fillRule="evenodd" clipRule="evenodd" d="M12.8929 17.3216C14.1583 16.4499 13.5396 14.4534 11.9931 14.4534C10.4606 14.4534 9.84192 16.4499 11.1073 17.3216C11.2338 17.42 11.276 17.5887 11.2198 17.7293L9.99658 20.4288H13.9896L12.7804 17.7293C12.7242 17.5887 12.7664 17.42 12.8929 17.3216Z" fill="white"/>
            </g>
            <defs>
            <clipPath id="clip0_148_3538">
                <rect width="24" height="24" fill="white"/>
            </clipPath>
            </defs>
        </svg>
    </>
  )
}

export default Block;